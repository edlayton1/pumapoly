#include"bubble.hpp"

void print( Jugador* list, size_t tam )
{
	for(size_t i = 0; i < tam; ++i)
	{
		printf("%d, ", list[ i ].dineroFinal );
	}
	printf("\n");
}

void swap( Jugador* val1, Jugador* val2 )
{
	Jugador tmp = *val1;

	*val1 = *val2;
	*val2 = tmp;
}

void bubble_desc( Jugador list[], size_t num_elems )
{
	bool done = false;

	for(size_t i = 0; i < num_elems-1 && done == false; i++)
	{
		done = true;

		for(size_t j = num_elems-1; j > i; j--)
		{
			if( list[j].dineroFinal > list[j-1].dineroFinal )
			{
				swap( &list[j], &list[j-1] );
				done = false;
			}
		}
	}
}

void bubble_asc( Jugador list[], size_t num_elems )
{
	bool done = false;

	for(size_t i = 0; i < num_elems-1 && done == false; i++)
	{
		done = true;

		for(size_t j = num_elems-1; j > i; j--)
		{
			if( list[j].dineroFinal < list[j-1].dineroFinal )
			{
				swap( &list[j], &list[j-1] );
				done = false;
			}
		}
	}
}

void BubbleSort( Jugador list[], size_t num_elems, int direction )
{
	if(direction == ASCENDING)
	{
		bubble_asc( list, num_elems );
	}
	else
	{
		bubble_desc( list, num_elems );
	}
}
