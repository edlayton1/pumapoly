var searchData=
[
  ['jugador',['Jugador',['../structJugador.html',1,'']]]
];
