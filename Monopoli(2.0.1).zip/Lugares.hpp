#ifndef _LUGARES_INC_
#define _LUGARES_INC_

#include "DLL.hpp"
#include "Vertex.hpp"

DLL* crearTablero();

#endif
