var searchData=
[
  ['vertex',['Vertex',['../class_vertex.html',1,'']]]
];
