var searchData=
[
  ['stack',['Stack',['../struct_stack.html',1,'']]]
];
