var searchData=
[
  ['name',['name',['../class_vertex.html#a14e4b85b8ddd1204e3e79daea7eff8d8',1,'Vertex']]],
  ['node',['Node',['../struct_node.html',1,'']]]
];
