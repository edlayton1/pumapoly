var searchData=
[
  ['elegirtarjeta',['elegirTarjeta',['../_monopoly_8cpp.html#a7ba03db274b775d158d1d1e462050cbd',1,'elegirTarjeta(int tarjetas[]):&#160;Monopoly.cpp'],['../_monopoly_8hpp.html#a7ba03db274b775d158d1d1e462050cbd',1,'elegirTarjeta(int tarjetas[]):&#160;Monopoly.cpp']]]
];
