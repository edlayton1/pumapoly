var searchData=
[
  ['lanzardados',['lanzarDados',['../_monopoly_8cpp.html#a6d5da4db2c58c7fdd5128c050b7e6419',1,'lanzarDados():&#160;Monopoly.cpp'],['../_monopoly_8hpp.html#ad6b0c362e4f929f490b8134537bc3f10',1,'lanzarDados():&#160;Monopoly.cpp']]]
];
