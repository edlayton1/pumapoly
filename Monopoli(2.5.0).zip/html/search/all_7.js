var searchData=
[
  ['jugador',['Jugador',['../struct_jugador.html',1,'']]]
];
