#ifndef _LUGARES_INC_
#define _LUGARES_INC_

#include "DLL.h"

DLL* crearTablero();

#endif
