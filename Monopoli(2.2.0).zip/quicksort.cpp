#include <iostream>
#include<iso646.h>
#include"quicksort.hpp"

void print( Item list[], size_t tam, char* msg )
{
    printf("%s", msg );

	for(size_t i = 0; i < tam; i++)
	{
		printf("%d, ", list[ i ]);
	}
	printf("\n");
}

void swap( Jugador* val1, Jugador* val2 )
{
	Jugador tmp = *val1;

	*val1 = *val2;
	*val2 = tmp;
}

void quick_sort_asc( Jugador list[], size_t first, size_t last )
{
    size_t mid = (first+last)/2;
    Item piv = list[mid].dineroFinal;
    size_t x0 = first;
    size_t x1 = last;

    while( x0 <= x1 )
    {
        while( list[x0].dineroFinal < piv )
        {
            x0++;
        }

        while( list[x1].dineroFinal > piv )
        {
            x1--;
        }

        if( x0 <= x1 )
        {
            swap( &list[x0], &list[x1] );
            x0++;
            x1--;
        }
    }

    if( first < x1 )
    {
        quick_sort_asc( list, first, x1 );
    }

    if( x0 < last )
    {
        quick_sort_asc( list, x0, last );
    }
}

void quick_sort_desc( Jugador list[], size_t first, size_t last )
{
    size_t mid = (first+last)/2;
    Item piv = list[mid].dineroFinal;
    size_t x0 = first;
    size_t x1 = last;

    while( x0 <= x1 )
    {
        while( list[x0].dineroFinal > piv )
        {
            x0++;
        }

        while( list[x1].dineroFinal < piv )
        {
            x1--;
        }

        if( x0 <= x1 )
        {
            swap( &list[x0], &list[x1] );
            x0++;
            x1--;
        }
    }

    if( first < x1 )
    {
        quick_sort_desc( list, first, x1 );
    }

    if( x0 < last )
    {
        quick_sort_desc( list, x0, last );
    }
}

void Quick_Sort( Jugador list[], size_t num_elems, int direction )
{
	if(direction == ASCENDING)
	{
		quick_sort_asc( list, 0, num_elems-1 );
	}
	else
	{
		quick_sort_desc( list, 0, num_elems-1 );
	}
}
